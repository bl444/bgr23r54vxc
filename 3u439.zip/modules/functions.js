const moment = require("moment");
require("moment-duration-format");
const util = require("util")
const {promisify} = require("util");
const readdir = promisify(require("fs").readdir);
const readfile = promisify(require("fs").readFile)
const writefile = promisify(require("fs").writeFile)
const Request = require('request')

const disc = require("discord.js")
var databaseQueue = {}

module.exports = (client) => {

  // Dependency
  
  function getRand(arr, dumpArr) {
  let rand = arr[Math.floor(Math.random() * arr.length)] || arr[0]
  let element = dumpArr.find(x => x == rand)
  if (!element) {
   return rand
  } else {
   return getRand(arr) 
  }
}

function getRandFromArray(arr, num) {
  let returningArr = []
  for (let i = 0; i < num; i++) {
    let rand = getRand(arr, returningArr)
    returningArr.push(rand)
  }
  return returningArr
}

function chooseFromElements(arr) {
  return arr[Math.floor(Math.random() * arr.length)] || arr[0]
}
  
    function constructEmbed(title, text, user, color) {
      let embed = new disc.RichEmbed()
      embed.setTitle(title || "Prompt")
      embed.setDescription(text)
      embed.setColor(color || [30, 144, 255])
      embed.setFooter("Powered by " + client.user.tag)
      embed.setTimestamp()
      if (user) {
       embed.setAuthor(user.username, user.displayAvatarURL) 
      }
      return embed

    }

  
  
  
    function randRange(min, max) {
      let range = (max - min) + 1
      return Math.floor((Math.random() * range) + min)
    }
  
    client.getUserFromName = function(name, guild) {
     if (guild) {
       let user = guild.members.find(u => u.user.username.toLowerCase().indexOf(name.toLowerCase()) == 0)
       return user
     } else {
       let user = client.users.find(u => u.username.toLowerCase().indexOf(name.toLowerCase()) == 0)
       return user
     }
     
    }

    client.postModLog = function (member, logType, moderator, length, reason, msg) {
      let profileURL = member.user.displayAvatarURL
      let username = member.user.tag
      let attachedFiles = msg.attachments.array()
      let proof = attachedFiles[0]
      
      if (length) {
       let embed = new disc.RichEmbed()
       embed.setTitle("Mute by " + moderator.username)
       embed.setAuthor(username, profileURL)
       embed.setDescription("Muted for **" + moment.duration(length).format("D [days], H [hours], m [minutes], s [seconds]") + "**.\nReason: " + reason + ".")
       embed.setFooter("Powered by " + client.user.tag)
       embed.setTimestamp()
       embed.setColor([255, 255, 0])
       if (proof) {
         embed.setImage(proof.url)
       }
       client.channels.get('556927136225820672').send({embed})
      } else {
       let embed = new disc.RichEmbed()
       embed.setTitle(logType + " by " + moderator.username)
       embed.setAuthor(username, profileURL)
       embed.setDescription("Reason: " + reason + ".")
       embed.setFooter("Powered by " + client.user.tag)
       embed.setTimestamp()
       embed.setColor([255, 255, 0])
       if (proof) {
         embed.setImage(proof.url)
       }
       client.channels.get('556927136225820672').send({embed}) 
      }
      
    }
  
    client.sendItemEmbed = function (name, id, stock, price, channel, title) {
        const embed = new disc.RichEmbed()
        embed.setColor('GREEN')
        stock = stock || ""
        price = price || "Unknown"
        let desc = ""
        let url = "https://www.roblox.com/catalog/" + id
        embed.setTitle(`${title || name}`)
        if (parseInt(price)) {
          if (price == 0) {
            desc = desc + `FREE!`
          } else {
            desc = desc + `${price}R$\n`
          }
        }
	desc = desc + url + "\n"
        if (parseInt(stock)) {
          desc = desc + `Item stock: ${stock}\n`
        }
        if (title) {
          desc = desc + name
        }

        // embed.setURL(`https://www.roblox.com/catalog/${id}`)
        embed.setDescription(desc)
        embed.setFooter("Gotta get it, quick")
        embed.setThumbnail(`https://www.roblox.com/asset-thumbnail/image?assetId=${id}&width=420&height=420&format=png`)
        embed.setTimestamp()
        channel.send({embed})
    }
  
    client.permlevel = (message, data) => {
      let permlvl = 0;

      const permOrder = client.config.rankData.slice(0).sort((p, c) => p.level < c.level ? 1 : -1);

      while (permOrder.length) {
        const currentLevel = permOrder.shift();
        if (message.guild && currentLevel.guildOnly) continue;

          if (currentLevel.check(message, client, data) ) {
          permlvl = currentLevel.level;
           break
          }


      }
    return permlvl;
  };

  client.logJoin = (joinType, name, id, serverId, isVIP) => {
    let logs = client.channels.get('523280086787555329')
    let thumbnail = `https://www.roblox.com/bust-thumbnail/image?userId=${id}&width=420&height=420&format=png`

    if (joinType == "add") {
      let embed = new disc.RichEmbed()
      embed.setDescription(`${name} has joined a server.\nServer ID: ${serverId}`)
      if (isVIP) {
	 embed.addField("Joined VIP server", "Owner: " + isVIP)
      }
      embed.setColor('GREEN')
      embed.setThumbnail(thumbnail)
      embed.setTimestamp()
      embed.setFooter("Powered by " + client.user.tag)
      logs.send(embed)
    }
    if (joinType == "leave") {
      let embed = new disc.RichEmbed()
      embed.setDescription(`${name} has left a server.\nServer ID: ${serverId}`)
      if (isVIP) {
	embed.addField("Joined VIP server", "Owner: " + isVIP)
      }
      embed.setColor('RED')
      embed.setThumbnail(thumbnail)
      embed.setTimestamp()
      embed.setFooter("Powered by " + client.user.tag)
      logs.send(embed)
    }
  }

  client.convertTime = function(string) {
    function returnMultiplier(letter) {
      let times = {
        "ms": 0.001,
        "s" : 1,
        "m" : 60,
        "h" : 3600,
        "d" : 86400,
        "w" : 86400 * 7,
        "y" : 31536000
      }
      return times[letter]
     }
     if (!string) return;
     if (string.match("-")) return;
     let number = parseFloat(string.match(/[\d\.]+/))
     let r = string.replace(/[^a-zA-Z]+/g, '');
     let multiplier = returnMultiplier(r)

     if (number && multiplier) {
       return [number, multiplier]
     } else {
       return;
     }
  }

    client.removeAccents = function (strAccents) {
		var strAccents = strAccents.split('');
		var strAccentsOut = new Array();
		var strAccentsLen = strAccents.length;
		var accents = 'ÀÁÂÃÄÅàáâãäåÒÓÔÕÕÖØòóôõöøÈÉÊËèéêëðÇçÐÌÍÎÏìíîïÙÚÛÜùúûüÑñŠš§§ŸÿýŽž';
		var accentsOut = "AAAAAAaaaaaaOOOOOOOooooooEEEEeeeeeCcDIIIIiiiiUUUUuuuuNnSsSsYyyZz";
		for (var y = 0; y < strAccentsLen; y++) {
			if (accents.indexOf(strAccents[y]) != -1) {
				strAccentsOut[y] = accentsOut.substr(accents.indexOf(strAccents[y]), 1);
			} else
				strAccentsOut[y] = strAccents[y];
		}
		strAccentsOut = strAccentsOut.join('');
		return strAccentsOut;
	}

  client.awaitReply = async (msg, question, options, limit = 60000) => {
    const filter = m => m.author.id === msg.author.id;
    await msg.channel.send(question, options);
    try {
      const collected = await msg.channel.awaitMessages(filter, { max: 1, time: limit, errors: ["time"] });
      return collected.first().content;
    } catch (e) {
      return false;
    }
  };
  
  client.getData = async (key) => {
    let data = await client.redisClient.get(key)
    console.log(data)
    return data
  }

  client.setData = async (key, val, toSet) => {
    
    
    let data = await client.redisClient.set(key, val)
    return data
    
    
  }
     client.incrementLog = function (userid, logType, moderator, length, reason) {
     client.getData(userid + "-LOGS").then(data => {
       if (data) {
        let jData = JSON.parse(data)
        if (jData[logType]) {
         let now = Date.now()
         if (logType == "kicks") {
          jData.mutes = [] 
         }
         jData[logType].push({
           mod: moderator,
           length: length,
           reason: reason,
           timestamp: now
         })
         client.setData(userid + "-LOGS", JSON.stringify(jData))
        }
       }
       
     })
     
      
    }
  client.loadCommand = (commandName) => {
    try {
      const props = require(`../commands/${commandName}`);
      client.logger.log(`Command  "${props.help.name}" was loaded. 👌`);
      if (props.init) {
        props.init(client);
      }
      client.commands.set(props.help.name, props);
      props.conf.aliases.forEach(alias => {
        client.aliases.set(alias, props.help.name);
      });
      return false;
    } catch (e) {
      return `Unable to load command due to error: ${commandName}: ${e}`;
    }
  };

  client.unloadCommand = async (commandName) => {
    let command;
    if (client.commands.has(commandName)) {
      command = client.commands.get(commandName);
    } else if (client.aliases.has(commandName)) {
      command = client.commands.get(client.aliases.get(commandName));
    }
    if (!command) return `The command \`${commandName}\` doesn"t seem to exist, nor is it an alias. Try again!`;

    if (command.shutdown) {
      await command.shutdown(client);
    }
    delete require.cache[require.resolve(`../commands/${commandName}.js`)];
    return false;
  };

  String.prototype.toProperCase = function() {
    return this.replace(/([^\W_]+[^\s-]*) */g, function(txt) {return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
  };




  client.wait = require("util").promisify(setTimeout);

  // check permissions for discord
  client.checkPerm = function(guildMember, permissionName) {
    try {
      return guildMember.hasPermission(permissionName)
    } catch (e) {
      console.log('check perm fail: ' + e)
      // client.startChannel.send('check permission failure: ' + e)
    }
  }

  client.hastebin = async function(input) {
    const {post} = require('snekfetch')
    const { body } = await post('https://hastebin.com/documents').send(input)
    let key = body.key
    return "https://hastebin.com/" + key
  }
  // These 2 process methods will catch exceptions and give *more details* about the error and stack trace.
  process.on("uncaughtException", (err) => {
    const errorMsg = err.stack.replace(new RegExp(`${__dirname}/`, "g"), "./");
    client.logger.error(`Uncaught Exception:\n${errorMsg}`);

     if (client.startChannel) {
      client.startChannel.send("error, rebooting (check logs)")
     }
    // p
    process.exit(143);
  });

  process.on("unhandledRejection", err => {
    const errorMsg = err.stack.replace(new RegExp(`${__dirname}/`, "g"), "./");
    client.logger.error(`Unhandled rejection: ${errorMsg}`);
  });
  
  
};

