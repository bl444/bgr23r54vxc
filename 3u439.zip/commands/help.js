
exports.run = (client, message, args, level) => {
  // if no specific command is called show all commands
  const discord = require("discord.js")
  let commands = client.commands.array()
  let names = {}
  let x
  function addCommandToList(command) {
    if (!names[command.help.category]) {
      names[command.help.category] = [
        command.help.name
      ]
    } else {
      names[command.help.category].push(command.help.name)
    }
  }
  for (x in commands) {
    let cmd = commands[x]
      addCommandToList(cmd);
  }
  const embed = new discord.RichEmbed()
  embed.setTitle("Commands:")
  embed.setColor('#751aff')
  for (x in names) {
    embed.addField(x, names[x].join(", "))
  }
  embed.setDescription("Join the JJStudios Group! [click here :point_left: :weary:](https://www.roblox.com/groups/8414422/JJStudios/)")
  message.channel.send({embed})
};
exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ["cmds", "cmd", "help", "daddypls"],
  permLevel: "User"
};
exports.help = {
  name: "help",
  category: "Other",
  description: "Responds with every command shown to you.",
  usage: "help [command]"
};
