const Discord = require("discord.js");

exports.run = async (client, message, args, level) => { // eslint-disable-line no-unused-vars
  let all = message.guild.roles.find(r => r.name == "@everyone")
  message.channel.overwritePermissions(all, {
    SEND_MESSAGES: true

  }).then(message.channel.send(`${message.channel} was unlocked.`)) 
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [""],
  permLevel: "Trial Mod",
  gcOnly: true
};

exports.help = {
  name: "unlock",
  category: "Moderation",
  description: "Unlock a channel.",
  usage: "unlock"
};
