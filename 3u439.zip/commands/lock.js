const Discord = require("discord.js");

exports.run = async (client, message, args, level) => { // eslint-disable-line no-unused-vars
  let all = message.guild.roles.find(r => r.name == "@everyone")
  message.channel.overwritePermissions(all, {
    SEND_MESSAGES: false

  }).then(message.channel.send(`${message.channel} was locked.`)) 
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [""],
  permLevel: "Moderator",
  gcOnly: true
};

exports.help = {
  name: "lock",
  category: "Moderation",
  description: "Lock a channel.",
  usage: "lock"
};
