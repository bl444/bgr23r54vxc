exports.run = async (client, message, args, level) => {
  const friendly = client.config.rankData.find(l => l.level === level).name;
  message.reply(`Your role is **${friendly}**. (RankID ${level})`);
};

exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ["permlevel"],
  permLevel: "User"
};

exports.help = {
  name: "perms",
  category: "Utility",
  description: "Tells you your permissions level for the current message location.",
  usage: "perms"
};