const Discord = require("discord.js");

exports.run = async (client, message, [userr, ...reason], level) => { // eslint-disable-line no-unused-vars
  let user = message.mentions.members.first()
  if (user) {
     if (!reason) {
      reason = "No reason. Kicked by " + message.author.username + "."
     } else {
    reason = reason.join(' ')
     }
    var embed = new Discord.RichEmbed()
    embed.setTitle("You have been kicked.")
    embed.setDescription(`You were kicked from ${message.guild.name} for: ${reason}`)
    embed.setFooter("RIP")
    embed.setColor("RED")
    embed.setTimestamp()
    if (user.hasPermission("MANAGE_MESSAGES")) {
     return message.channel.send("The user is a moderator.") 
    }
    let name
    user.user.send({embed}).catch(e => message.channel.send("Failed to DM user."))
    user.kick(reason).then(s => {
    //  client.incrementLog(user.user.id, "kicks", message.author.id, null, reason)
     // client.postModLog(user, "Kick", message.author, null, reason, message)
      message.channel.send(user.user.username + " was kicked. Reason: " + reason)
    })
  } else {
   message.channel.send("Please provide a user to kick.") 
  }
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: "Moderator",
};

exports.help = {
  name: "kick",
  category: "Moderation",
  description: "Kick a user.",
  usage: "kick user"
};
