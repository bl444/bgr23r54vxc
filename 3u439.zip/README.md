For the new game and the JJ Studios Discord server and it's members.
